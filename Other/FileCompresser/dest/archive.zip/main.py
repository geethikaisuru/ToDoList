import FreeSimpleGUI as sg

label1 = sg.Text("Select files to compress")
input1 = sg.InputText(tooltip = "Select files you want to compress")
choose_button1 = sg.FilesBrowse("Choose", tooltip = "Select files to compress", key = "files")

label2 = sg.Text("Select where to compress")
input2 = sg.InputText(tooltip = "Select where you want to folder")
choose_button2 = sg.FolderBrowse("Choose", tooltip = "Select Destination compress", key = "folder")

compress_button = sg.Button("Compress", tooltip = "Compress the selected files")

window = sg.Window('File Compresser', layout = [[ label1, input1, choose_button1],
                                                [ label2, input2, choose_button2], [compress_button]])      

while True:
    event, values = window.read()
    print(values)
    print("That was Values\n")
    what = values['files'].split(";")
    where = values['folder']

    print(what, where)
    match event:
        case sg.WIN_CLOSED:
            break

window.close()
